import java.util.Scanner;

public class EmailVerification {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("enter your email address--> ");
        String email = scanner.nextLine();

        if (EmailVerificationMethod(email)) {
            System.out.println("valid email address ");
        } else {
            System.out.println("not valid email address");
        }

        scanner.close();
    }

    public static boolean EmailVerificationMethod(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

        return email.matches(emailRegex);
    }
}
