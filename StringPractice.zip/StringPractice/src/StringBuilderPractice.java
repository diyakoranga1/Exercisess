public class StringBuilderPractice {

    private StringBuilder content;

    public StringBuilderPractice() {
        this.content = new StringBuilder();
    }

    public StringBuilderPractice(String initialString) {
        this.content = new StringBuilder(initialString);
    }

    public void append(String str) {
        content.append(str);
    }

    public void insert(int index, String str) {
        if (index >= 0 && index <= content.length()) {
            content.insert(index, str);
        } else {
            System.out.println("Index out of bounds. Cannot insert.");
        }
    }

    public void delete(int startIndex, int endIndex) {
        if (startIndex >= 0 && endIndex < content.length() && startIndex <= endIndex) {
            content.delete(startIndex, endIndex + 1);
        } else {
            System.out.println("Invalid start or end index. Cannot delete.");
        }
    }

    @Override
    public String toString() {
        return content.toString();
    }

    public static void main(String[] args) {
        StringBuilderPractice myStringBuilder = new StringBuilderPractice("string ");

        myStringBuilder.append("Builder");
        System.out.println("After Appending --> " + myStringBuilder);

        myStringBuilder.insert(0, " meow ");
        System.out.println("After Inserting --> " + myStringBuilder);

        myStringBuilder.delete(0, 5);
        System.out.println("After Deleting --> " + myStringBuilder);
    }
}
