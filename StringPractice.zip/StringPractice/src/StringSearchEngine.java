import java.util.ArrayList;
import java.util.List;

public class StringSearchEngine {
    private String msg;

    public StringSearchEngine(String msg) {
        this.msg = msg;
    }

    public List<Integer> findAllOccurrences(String substring) {
        List<Integer> occurrences = new ArrayList<>();
        int index = msg.indexOf(substring);

        while (index != -1) {
            occurrences.add(index);
            index = msg.indexOf(substring, index + 1);
        }

        return occurrences;
    }

    public String highlightOccurrences(String substring) {
        List<Integer> occurrences = findAllOccurrences(substring);
        StringBuilder highlightedText = new StringBuilder(msg);

        int offset = 0;
        for (int i : occurrences) {
            highlightedText.insert(i + offset, "{");
            highlightedText.insert(i + offset + substring.length() + 1, "}"); // Adjusted index
            offset += 2; // Two extra characters added (braces)
        }

        return highlightedText.toString();
    }

    public static void main(String[] args) {
        StringSearchEngine obj = new StringSearchEngine("qwerty nff mew fmdl fjjv mew dnmew");

        String substringToSearch = "mew";
        List<Integer> occurrences = obj.findAllOccurrences(substringToSearch);

        System.out.println("All occurrences of '" + substringToSearch + "': " + occurrences);

        String hText = obj.highlightOccurrences(substringToSearch);
        System.out.println("Highlighted Text--> " + hText);
    }
}
