package com.hexaware.springcoredemo;

public class Client {
	public static void main(String[] args) {
	Vehicle t=new Cycle();
	Traveller obj=new Traveller(t);
	obj.startJourney();
	}
	

}
