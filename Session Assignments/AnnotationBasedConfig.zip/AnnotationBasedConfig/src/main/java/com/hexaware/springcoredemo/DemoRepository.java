package com.hexaware.springcoredemo;

import org.springframework.stereotype.Repository;

@Repository
public class DemoRepository {
	  public String hello(){
		  return "hello repo";}
}
