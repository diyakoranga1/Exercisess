package com.hexaware.springcoredemo;

import org.springframework.stereotype.Service;

@Service
public class DemoService {
	  public String hello(){
		  return "hello service";}
}
