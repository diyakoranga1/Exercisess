package com.hexaware.springcoredemo;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.hexaware.springcoredemo")
public class AppConfig {


}
