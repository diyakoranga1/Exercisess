package com.example.demo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("mysqlDatasource") 
@Primary
public class MysqlDatasource implements Datasource {
    @Override
    public void returnConnection() {
        System.out.println("Returning connection for MySQL datasource");
    }
}