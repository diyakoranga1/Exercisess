package com.example.demo;

import org.springframework.stereotype.Component;

@Component("postgresqlDatasource") 
public class PostgresqlDatasource implements Datasource {
    @Override
    public void returnConnection() {
        System.out.println("Returning connection for PostgreSQL datasource");
    }
    
}