package com.hexaware.springcoredemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class Client {
 public static void main(String[] args)
 { 
	 ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
	Traveller obj1 = applicationContext.getBean(Traveller.class);
    obj1.startJourney();
 }
}