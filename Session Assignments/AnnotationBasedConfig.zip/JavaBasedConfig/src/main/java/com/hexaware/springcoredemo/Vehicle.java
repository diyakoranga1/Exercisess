package com.hexaware.springcoredemo;

public interface Vehicle {
	public void move();

}
