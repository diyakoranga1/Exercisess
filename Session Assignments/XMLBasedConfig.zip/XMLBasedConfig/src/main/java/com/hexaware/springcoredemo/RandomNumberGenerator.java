package com.hexaware.springcoredemo;

public class RandomNumberGenerator {
	   private int randomNumber;
	   public int getRandomNumber() {
	      return randomNumber;
	   } 
	   public void setRandomNumber(int randomNumber) {
	      this.randomNumber = randomNumber;
	   }
	}