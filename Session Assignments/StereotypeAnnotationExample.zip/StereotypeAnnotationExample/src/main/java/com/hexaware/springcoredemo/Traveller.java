package com.hexaware.springcoredemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("traveller")
public class Traveller {
    private Vehicle obj = null;

    @Autowired
    public Traveller(Vehicle t) {
        super();
        this.obj = t;
    }

    public void startJourney() {
        this.obj.move();
    }
}
