package com.example.demo;


import org.springframework.stereotype.Component;

public interface Datasource {
    void returnConnection();
}


