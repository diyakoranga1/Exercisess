package com.hexaware.springcoredemo;

public class Traveller {
	//private Car carObj=null;
	private Vehicle obj=null;
	public Traveller(Vehicle t) {
		super();
		this.obj=t;
	}
	public void startJourney() {
		this.obj.move();
	}
}
