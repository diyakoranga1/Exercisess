package com.hexaware.springcoredemo;

public class Bike implements Vehicle  {
	@Override 
	public void move() {
		System.out.println("bike is moving  ");
	}

}
