package com.hexaware.mainpkg;

import java.util.ArrayList;
import java.util.logging.Logger;
import com.hexaware.dao.ServiceProviderImpl;
import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.myexceptions.AccountNumberInvalidException;
import com.hexaware.myexceptions.InsufficientFundsException;
import com.hexaware.myexceptions.NegativeAmountException;

public class MainMod {
    private static final Logger LOGGER = Logger.getLogger(MainMod.class.getName());

    public static void main(String[] args) throws InsufficientFundsException, AccountNumberInvalidException,
            NegativeAmountException {

        // TODO Auto-generated method stub
        BankAccount obj1 = new BankAccount("xyz", "Current", 80000);
        BankAccount obj2 = new BankAccount("abc", "Savings", 30440);
        BankAccount obj3 = new BankAccount("mew", "Current", 90485);

        ArrayList<BankAccount> myList = new ArrayList<>();
        myList.add(obj1);
        myList.add(obj2);
        myList.add(obj3);

        Bank myBank = new Bank("SBI", myList);

        ServiceProviderImpl myObj = new ServiceProviderImpl(myBank);

        LOGGER.info("Main Program is starting ");

        try {
            int accountNo = 1;
            LOGGER.info("Checking balance for account number : " + accountNo);
            System.out.println("Balance of account " + accountNo + " : " + myObj.checkBalance(accountNo));
            
            LOGGER.info("Depositing 12000 to account number: " + accountNo);
            System.out.println("Status of deposit: " + myObj.deposit(accountNo, 12000));

            LOGGER.info("Checking balance for account number "+accountNo+" after depositing some amount: "  );
            System.out.println("Balance of account number " + accountNo + " is " + myObj.checkBalance(accountNo));
        } catch (NegativeAmountException e) {
            LOGGER.warning("NegativeAmountException: " + e.getMessage());
            throw new NegativeAmountException("Balance cannot be negative");
        } catch (AccountNumberInvalidException e) {
            LOGGER.warning("AccountNumberInvalidException: " + e.getMessage());
            throw new AccountNumberInvalidException("Account number is invalid");
        } finally {
            LOGGER.info("all details of the bank-> " + myBank);
        }

        LOGGER.info("MainMod program completed.");
    }
}